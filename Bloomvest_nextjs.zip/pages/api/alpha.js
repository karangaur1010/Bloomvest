
export default async function handler(req, res) {
  const { query } = req;
  const ALPHA_KEY = process.env.ALPHA_VANTAGE_KEY;
  if (!ALPHA_KEY) {
    res.status(500).json({ error: 'Server missing ALPHA_VANTAGE_KEY environment variable' });
    return;
  }

  // Build Alpha Vantage URL
  const params = new URLSearchParams({ apikey: ALPHA_KEY, ...query });
  const url = `https://www.alphavantage.co/query?${params.toString()}`;

  try {
    const r = await fetch(url);
    const data = await r.json();
    res.setHeader('Cache-Control', 's-maxage=30, stale-while-revalidate=59');
    res.status(200).json(data);
  } catch (err) {
    console.error(err);
    res.status(502).json({ error: 'Failed to fetch from Alpha Vantage' });
  }
}


import { useEffect, useState } from 'react';
import {
  LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell, BarChart, Bar
} from 'recharts';

const initialPortfolio = [
  { ticker: 'AAPL', qty: 50, cost: 120 },
  { ticker: 'MSFT', qty: 30, cost: 200 },
  { ticker: 'TSLA', qty: 10, cost: 600 },
];

const sectorsMap = {
  'AAPL': 'Technology',
  'MSFT': 'Technology',
  'TSLA': 'Automotive',
  'AMZN': 'Consumer Discretionary',
  'GOOGL': 'Technology',
  'JPM': 'Financials'
};

export default function Home() {
  const [portfolio, setPortfolio] = useState(initialPortfolio.map(p=>({...p, price: null})));
  const [selected, setSelected] = useState('AAPL');
  const [history, setHistory] = useState({}); // {ticker: [{date, close}]}
  const [indicators, setIndicators] = useState({}); // {ticker: {smaShort, smaLong, rsi, bb, macd}}
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(()=>{ fetchPrices(); }, []);

  useEffect(()=>{ fetchIndicators(selected); }, [selected]);

  async function apiAlpha(query) {
    const q = new URLSearchParams(query).toString();
    const res = await fetch('/api/alpha?'+q);
    if(!res.ok) throw new Error('API proxy error');
    return res.json();
  }

  async function fetchPrices() {
    try{
      setLoading(true);
      const updated = await Promise.all(portfolio.map(async p=>{
        const data = await apiAlpha({ function: 'GLOBAL_QUOTE', symbol: p.ticker });
        const price = parseFloat(data['Global Quote']?.['05. price'] || 0);
        return {...p, price: price || p.cost};
      }));
      setPortfolio(updated);
      setLoading(false);
    }catch(err){
      console.error(err);
      setError('Failed to fetch prices or rate-limited');
      setLoading(false);
    }
  }

  async function fetchIndicators(ticker) {
    try{
      setLoading(true);
      setError('');
      const histJson = await apiAlpha({ function: 'TIME_SERIES_DAILY_ADJUSTED', symbol: ticker, outputsize: 'compact' });
      const ts = histJson['Time Series (Daily)'] || {};
      const dates = Object.keys(ts).slice(0,120).reverse();
      const histArr = dates.map(d=>({date:d, close: parseFloat(ts[d]['4. close'])}));
      setHistory(prev=>({...prev, [ticker]: histArr}));

      const sma10 = await apiAlpha({ function: 'SMA', symbol: ticker, interval: 'daily', time_period: 10, series_type: 'close' });
      const sma10Series = sma10['Technical Analysis: SMA'] || {};
      const sma10Arr = dates.map(d=>({date:d, SMA10: sma10Series[d]? parseFloat(sma10Series[d]['SMA']): null}));

      const sma50 = await apiAlpha({ function: 'SMA', symbol: ticker, interval: 'daily', time_period: 50, series_type: 'close' });
      const sma50Series = sma50['Technical Analysis: SMA'] || {};
      const sma50Arr = dates.map(d=>({date:d, SMA50: sma50Series[d]? parseFloat(sma50Series[d]['SMA']): null}));

      const rsi = await apiAlpha({ function: 'RSI', symbol: ticker, interval: 'daily', time_period: 14, series_type: 'close' });
      const rsiSeries = rsi['Technical Analysis: RSI'] || {};
      const rsiArr = dates.map(d=>({date:d, RSI: rsiSeries[d]? parseFloat(rsiSeries[d]['RSI']): null}));

      const bb = await apiAlpha({ function: 'BBANDS', symbol: ticker, interval: 'daily', time_period: 20, series_type: 'close', nbdevup:2, nbdevdn:2 });
      const bbSeries = bb['Technical Analysis: BBANDS'] || {};
      const bbArr = dates.map(d=>({date:d, UB: bbSeries[d]? parseFloat(bbSeries[d]['Real Upper Band']): null, MB: bbSeries[d]? parseFloat(bbSeries[d]['Real Middle Band']): null, LB: bbSeries[d]? parseFloat(bbSeries[d]['Real Lower Band']): null}));

      const macd = await apiAlpha({ function: 'MACD', symbol: ticker, interval: 'daily', series_type: 'close' });
      const macdSeries = macd['Technical Analysis: MACD'] || {};
      const macdArr = dates.map(d=>({date:d, MACD: macdSeries[d]? parseFloat(macdSeries[d]['MACD']): null, MACD_Signal: macdSeries[d]? parseFloat(macdSeries[d]['MACD_Signal']): null}));

      setIndicators(prev=>({...prev, [ticker]: {smaShort: sma10Arr, smaLong: sma50Arr, rsi: rsiArr, bb: bbArr, macd: macdArr}}));
      setLoading(false);
    }catch(err){
      console.error(err);
      setError('Failed to fetch indicators (API limit?).');
      setLoading(false);
    }
  }

  const portfolioValue = portfolio.reduce((acc,p)=> acc + p.qty * (p.price||0), 0);
  const portfolioCost = portfolio.reduce((acc,p)=> acc + p.qty * p.cost, 0);
  const portfolioPL = portfolioValue - portfolioCost;
  const plPerStock = portfolio.map(p=>({ticker:p.ticker, PL: Math.round(( (p.price||0) - p.cost) * p.qty)}));

  const sectorValues = {};
  portfolio.forEach(p=>{
    const sector = sectorsMap[p.ticker] || 'Other';
    sectorValues[sector] = (sectorValues[sector] || 0) + (p.qty * (p.price||0));
  });
  const sectorData = Object.keys(sectorValues).map(k=>({name:k, value: sectorValues[k]}));

  function mergedForPlot(ticker) {
    const h = history[ticker] || [];
    const ind = indicators[ticker] || {};
    const sma10Map = (ind.smaShort||[]).reduce((acc,r)=>({...acc, [r.date]: r.SMA10}), {});
    const sma50Map = (ind.smaLong||[]).reduce((acc,r=>({...acc, [r.date]: r.SMA50}), {});
    const bbMap = (ind.bb||[]).reduce((acc,r)=>({...acc, [r.date]: {UB:r.UB, MB:r.MB, LB:r.LB}}), {});
    return h.map(d=> ({...d, SMA10: sma10Map[d.date]||null, SMA50: sma50Map[d.date]||null, ...(bbMap[d.date]||{})}));
  }

  // MA crossover
  function macrossoverSignal(ticker) {
    const ind = indicators[ticker];
    if(!ind || !ind.smaShort || !ind.smaLong) return 'No data';
    const shortMap = Object.fromEntries(ind.smaShort.map(d=>[d.date, d.SMA10]));
    const longMap = Object.fromEntries(ind.smaLong.map(d=>[d.date, d.SMA50]));
    const dates = Object.keys(shortMap).filter(d=> longMap[d]).sort();
    if(dates.length<2) return 'Insufficient data';
    const last = dates[dates.length-1], prev = dates[dates.length-2];
    const lastShort = shortMap[last], lastLong = longMap[last];
    const prevShort = shortMap[prev], prevLong = longMap[prev];
    if(prevShort <= prevLong && lastShort > lastLong) return 'Bullish crossover (Buy)';
    if(prevShort >= prevLong && lastShort < lastLong) return 'Bearish crossover (Sell)';
    return 'No crossover';
  }

  return (
    <div style={{maxWidth:1100, margin:'36px auto', padding:20}}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>Bloomvest (Next.js)</h1>
        <div>
          <button onClick={()=>{ fetchPrices(); fetchIndicators(selected); }}>Refresh</button>
        </div>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'1fr 320px', gap:20, marginTop:18}}>
        <div>
          <div style={{padding:12, background:'#fff', borderRadius:8, boxShadow:'0 1px 3px rgba(0,0,0,0.06)'}}>
            <h3>Portfolio Summary</h3>
            <div style={{fontSize:20, fontWeight:700}}>₹{Math.round(portfolioValue).toLocaleString()}</div>
            <div style={{color:'#6b7280'}}>Unrealized P/L: ₹{Math.round(portfolioPL).toLocaleString()}</div>
          </div>

          <div style={{marginTop:12, padding:12, background:'#fff', borderRadius:8}}>
            <h3>Profit / Loss per Stock</h3>
            <div style={{height:220}}>
              <ResponsiveContainer>
                <BarChart data={plPerStock}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="ticker" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="PL" name="P/L" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={{marginTop:12, padding:12, background:'#fff', borderRadius:8}}>
            <h3>Price & Indicators — {selected}</h3>
            {history[selected] ? (
              <div style={{height:340}}>
                <ResponsiveContainer>
                  <LineChart data={mergedForPlot(selected)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tick={{fontSize:10}} />
                    <YAxis domain={['auto','auto']} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="close" stroke="#3182ce" dot={false} name="Close" />
                    <Line type="monotone" dataKey="SMA10" stroke="#ff7300" dot={false} name="SMA(10)" />
                    <Line type="monotone" dataKey="SMA50" stroke="#ef4444" dot={false} name="SMA(50)" />
                    <Line type="monotone" dataKey="UB" stroke="#a78bfa" dot={false} name="BB Upper" />
                    <Line type="monotone" dataKey="MB" stroke="#7c3aed" dot={false} name="BB Middle" />
                    <Line type="monotone" dataKey="LB" stroke="#c4b5fd" dot={false} name="BB Lower" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (<div>Loading chart...</div>)}
            <div style={{marginTop:8, color:'#374151'}}>MA Crossover Signal: <strong>{macrossoverSignal(selected)}</strong></div>
          </div>

          <div style={{marginTop:12, padding:12, background:'#fff', borderRadius:8}}>
            <h3>MACD — {selected}</h3>
            {indicators[selected] && indicators[selected].macd ? (
              <div style={{height:220}}>
                <ResponsiveContainer>
                  <LineChart data={(indicators[selected].macd || [])}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tick={{fontSize:10}} />
                    <YAxis domain={['auto','auto']} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="MACD" stroke="#ef4444" dot={false} />
                    <Line type="monotone" dataKey="MACD_Signal" stroke="#2563eb" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (<div>Loading MACD...</div>)}
          </div>

        </div>

        <div style={{display:'flex', flexDirection:'column', gap:12}}>
          <div style={{padding:12, background:'#fff', borderRadius:8}}>
            <h3>Holdings</h3>
            <ul>
              {portfolio.map(p=> <li key={p.ticker}>{p.ticker} — {p.qty} shares — Cost ₹{p.cost}</li>)}
            </ul>
          </div>

          <div style={{padding:12, background:'#fff', borderRadius:8}}>
            <h3>Sector Allocation</h3>
            <div style={{height:240}}>
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={sectorData} dataKey="value" nameKey="name" outerRadius={80} label>
                    {sectorData.map((entry, index) => <Cell key={index} />)}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={{padding:12, background:'#fff', borderRadius:8}}>
            <h3>Select Ticker</h3>
            {portfolio.map(p=> (
              <div key={p.ticker} style={{marginBottom:8}}>
                <button onClick={()=>setSelected(p.ticker)} style={{background:'transparent', color:'#2563eb', border:'none', cursor:'pointer'}}>{p.ticker}</button>
              </div>
            ))}
            <div style={{marginTop:8, color:'#6b7280', fontSize:12}}>API key is stored server-side. Set ALPHA_VANTAGE_KEY in Vercel or .env.local</div>
          </div>
        </div>

      </div>
    </div>
  )
}

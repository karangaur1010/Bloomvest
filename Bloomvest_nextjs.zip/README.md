
# Bloomvest (Next.js)

Bloomvest converted to a Next.js app. This version uses server-side API routes to proxy Alpha Vantage requests so your API key stays secret.

## Features included
- Live portfolio & price tracker
- Historical charts
- Technical indicators (SMA, RSI, Bollinger Bands, MACD)
- Profit/Loss per stock chart
- Sector allocation chart
- Moving-average crossover signals

## Setup (local)
1. Install dependencies
```bash
npm install
```
2. Set environment variable (create `.env.local`):
```
ALPHA_VANTAGE_KEY=YOUR_API_KEY
```
3. Run dev server
```bash
npm run dev
```
Open http://localhost:3000

## Deploying to Vercel
1. Import project to Vercel or connect your GitHub repo.
2. In Vercel project settings, add an Environment Variable:
   - Key: `ALPHA_VANTAGE_KEY`
   - Value: your API key (e.g. ZIWAHOULNW5ZDLEC)
3. Deploy — Vercel will build and use the server-side API routes to proxy Alpha Vantage.

IMPORTANT: Do **not** embed your API key into client-side code. Use the environment variable method above.
